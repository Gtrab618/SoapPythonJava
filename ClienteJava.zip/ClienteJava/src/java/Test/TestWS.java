/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Test;

import ws.WSOperaciones;
import ws.WSOperaciones_Service;

/**
 *
 * @author Usuario
 */
public class TestWS {
    
    
    public static void main(String[] args) {
        WSOperaciones_Service servicio= new WSOperaciones_Service();
        WSOperaciones cliente = servicio.getWSOperacionesPort();
        
        
        if(cliente.login("Pave1", "Pave12020")){
            System.out.println("Credenciales correctas");
        }else{
            System.out.println("Credenciales incorrectas");
        }
        
        //procesar pago
        System.out.println(cliente.procesoPago(500, 50));
    }
}
